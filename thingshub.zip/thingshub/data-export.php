<?php
include "header.php";

?>


  <div id="sidebar" class="col-xs-12 col-sm-6">

<div class="col-xs-12 col-sm-12">
		<h2>Data Exporting</h2>
		Download all of this Channel's feeds in CSV format. <br>
		<a href="download.php?c_id=<?php echo $channelId; ?>&download" class="btn btn-info">Download</a>
		</div>
  </div>
  <script type="text/javascript">_satellite.pageBottom();</script>

  </body>
</html>
      
  