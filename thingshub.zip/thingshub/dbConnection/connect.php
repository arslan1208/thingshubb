<?php
// database related info
		$host_name = "localhost";
		$host_username = "root";
		$host_password = "";
		$host_database = "thingspeak"; 
		/* $host_name = "localhost";
		$host_username = "notesgat_things";
		$host_password = "things@1232@";
		$host_database = "notesgat_thingshub";
		 */
		//1. connect database
		
		$conn = mysqli_connect($host_name, 
								$host_username, 
								$host_password, 
								$host_database);
		
		if(!$conn)
		{
			die("Database connection failed: " 
					. mysqli_error($conn) );
					echo "connection failed";
		}
?>