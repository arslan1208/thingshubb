<?php


	session_start();
	if(isset($_SESSION["my_session"]))
		{
			//include("./common/logout_header.php");
		}
		
	if(!isset($_SESSION["my_session"]))
	{
		header("Location: login.php");
	}

 
 include("dbConnection/connect.php");
 $userId=$_SESSION["user_id"];

 $field1="";
		$field2='';
		$field3='';
		$field4='';
		$field5='';
		$field6='';
		$field7='';
		$field8='';
 
		$name=$_POST['channelName'];
		$discription=$_POST['channelDiscription'];

		
			$field1=$_POST['field1'];
			$field2=$_POST['field2'];
			$field3=$_POST['field3'];
			$field4=$_POST['field4'];
			$field5=$_POST['field5'];
			$field6=$_POST['field6'];
			$field7=$_POST['field7'];
			$field8=$_POST['field8'];
			
			$metadata=$_POST['metaData'];
			// $access=$_POST['access'];
			$date = date('Y/m/d');
			echo $date;
//$tags=$_POST['tags'];
//$elevation=$_POST['elevation'];
//$showlocation=$_POST['showlocation'];

if($name==""||$discription==""){
                          $return=array(
					"title" =>"Parameter is missing!",
					"message" => "Parameter is missing.",
					"Error" => "true",
					"statusCode"=>"422"
					); 
				echo json_encode($return);
                                mysqli_close($conn);
				die();

             }
            else{
// Insert data into mysql
$sql="INSERT INTO channeltable (channelName,channelDescription, field1,field2,field3,field4,field5,field6,field7,field8,metaData,createdDate,updated,userId)
VALUES ('$name', '$discription', '$field1' , '$field2' , '$field3', '$field4', '$field5', '$field6', '$field7', '$field8','$metadata','$date','$date','$userId')";

$result = mysqli_query($conn,$sql);
$channel_id=mysqli_insert_id($conn);
$fields=array($field1,$field2,$field3,$field4,$field5,$field6,$field7,$field8);
			for($i=0;$i<count($fields);$i++){
				// if($fields[$i]!==""){
				$field_id=$i+1;
				mysqli_query($conn,"insert into fieldattr (channel_id,field_id,title) values ($channel_id,$field_id,'".$fields[$i]."')") or die(mysqli_error($conn));
				// }
			}
echo var_dump($result);

if($result){
	header("Location: ./mychannels.php");
}


else {
	echo mysqli_error;
echo "ERROR";
}
			}
?>

