<?php
 include("dbConnection/connect.php");
	
if(isset($_GET['download'])){
	$cols[]=['Time','ChannelId','Reading','Field'];
	 $query = mysqli_query($conn,'SELECT timeStamp,channelId,reading,field_id FROM `field-data` where channelId='.$_GET['c_id']) or die(mysqli_error($conn));
	$rows = mysqli_fetch_all($query);
		$rowss=array_merge($cols,$rows);
		// print_r($rowss);die;
		// ob_start();
		header('Content-Type: application/csv');
    // tell the browser we want to save it instead of displaying it
    header('Content-Disposition: attachment; filename="fieldData.csv";');

$file = fopen("php://output","w");

foreach ($rowss as $line)
  {
  fputcsv($file,$line);
  }
}
 