<?php
include "header.php";
?>
	
  <div class="datecontainer">
  
  <div id="reportrange" class="pull-left" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 3px solid #ccc; width: 30%">
    <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
    <span></span> <b class="caret"></b>
</div>
  </div>
 
<script>

var start;
 var end;
Highcharts.setOptions({
  global: {
    useUTC: false
  }
  // color: '#ccc',
});
  $(function() {

    start = moment().subtract(29, 'days');
    end = moment();

    function cb(start, end) {
		$('#reportrange span').html(isNaN(start)?'Live Data':start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
    loadGraphData(start,end,<?php echo $channelId; ?>);
		
	}

    $('#reportrange').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: {
           'Live': ['live', 'live'],
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);

    cb(start, end);
    
});
 function loadGraphData(startt,endd,channelIdd){
	$(".loader").show();
	ss = new Date(startt);
			ss=ss.valueOf()/1000;
			ee = new Date(endd);
			ee=ee.valueOf()/1000;
	 $.ajax({
				url: 'ajax.php',
				method: 'POST',
				// dataType: 'json',
				data: {action: 'getFieldDataByRange', channelId: channelIdd, start: ss, end: ee},
				success: function(result) {
					$(".graph_data").html(result);
					$(".loader").hide();
				}
	 });
 }
  </script>  

 
  <br> <br/>
  <?php
  
    if(isset($_POST['submit'])){
				mysqli_query($conn,"update fieldattr set title='".$_POST['title']."',color='".$_POST['color']."',results='".$_POST['results']."',`y-axis`='".$_POST['y-axis']."' where channel_id=".$_POST['channel_id']." and field_id=".$_POST['field_id']."") or die(mysqli_error($conn));
				// if(mysqli_affected_rows($con)>0)
					echo "<div class='alert alert-success'>Field Updated Successfully!</div>";
			}
			if(isset($_POST['comparison'])){
				$comparison_field=isset($_POST['comparison_field'])?json_encode($_POST['comparison_field']):"";
				mysqli_query($conn,"update channeltable set comparison_field='$comparison_field' where channelId=".$_GET['c_id']) or die(mysqli_error($conn));
				// if(mysqli_affected_rows($con)>0)
					echo "<div class='alert alert-success'>Added to Comparison successfully!</div>";
			}
			
			?>
  <div class="graph_data">
  		 </div>
	
  </body>
</html>
      
  