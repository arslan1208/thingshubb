<?php
// ob_start();
include("dbConnection/connect.php");
if(isset($_GET['live'])){
	$channelId=mysqli_real_escape_string($conn,$_GET['channelId']);
	$field_id=mysqli_real_escape_string($conn,$_GET['field_id']);
	$reading = rand(20, 25);
	$query = mysqli_query($conn, "Insert into `field-data` (channelId,reading,field_id) values($channelId,'$reading',$field_id)") or die(mysqli_error($con));
	echo mysqli_insert_id($conn)."<br>".$reading;
	// sleep(3000);
	// $page = $_SERVER['PHP_SELF'];
$sec = "2";
header("Refresh: $sec; url=addApi.php?channelId=$channelId&field_id=$field_id&live");
}
else{
	$channelId=mysqli_real_escape_string($conn,$_GET['channelId']);
	$reading=mysqli_real_escape_string($conn,$_GET['reading']);
	$field_id=mysqli_real_escape_string($conn,$_GET['field_id']);
		
	$query = mysqli_query($conn, "Insert into `field-data` (channelId,reading,field_id) values($channelId,'$reading',$field_id)") or die(mysqli_error($con));
		echo mysqli_insert_id($conn);
}
?>