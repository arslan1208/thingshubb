<?php session_start(); ?> 

<!DOCTYPE html>  
  
<html lang="en">  
<head>  
    <meta charset="utf-8">  
    <title>ThingsHub</title>  
    <meta name="viewport" content="width=device-width,initial-scale=1">  
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"> 
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>	
	
</head>  

  <body style='padding-top: 30px;'>
  
  

     <nav class="navbar navbar-inverse"  id="RedMenu">  
        <div class="container-fluid">  
            <!--Navbar Header Start Here-->  
            <div class="navbar-header">  
                <a class="navbar-brand" href="index.php"><font color="white">ThingsHub</font></a>  
				
            </div>  
            <!--Navbar Header End Here-->  
            <!--Menu Start Here-->  
            <ul class="nav navbar-nav " >  
                 <li class="dropdown">  
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">  
                        Channels  
                        <span class="caret"></span>  
                    </a>  
                    <ul class="dropdown-menu">  
                        <li><a href="mychannels.php">My channels</a></li>  
                        <li><a href="#">Watched channels</a></li>  
                        <li><a href="#">Public channels</a></li>  
                      
                    </ul>  
                </li> 
                <li><a href="#">Apps</a></li>  
				<li><a href="#">Community</a></li> 
                <!--dropdown Menu Start-->  
                <li bgcolor="#E6E6FA" class="dropdown" >  
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#"  >  
                        Support  
                        <span class="caret"></span>  
                    </a>  
                    <ul  class="dropdown-menu" >  
                        <li><a href="login.php">Documentation </a></li>  
                        <li><a href="#">Tutorial</a></li>  
                        <li><a href="#">Examples</a></li>  
                    </ul>  
                </li>  
                <!--dropdown Menu End-->  
                <li><a href="#">Contact Us</a></li>  
            </ul>  
            <!--Menu End Here-->  
            <!--Right Aligned Menu Start-->  
            <ul class="nav navbar-nav navbar-right">  
                 <li bgcolor="#E6E6FA" class="dropdown" >  
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#"  >  
                        Account  
                        <span class="caret"></span>  
                    </a>  
                    <ul  class="dropdown-menu" >  
                        <li><a href="login.php">My account </a></li>  
                        <li><a href="#">My profile</a></li>  
                         
                    </ul>  
                </li>  
                <li><a href="login.php">Sign out</a></li>  
            </ul>  
            
        </div>  


    </nav>  
	
	
	
	
    <div class="row">
      <ul class="nav nav-tabs" style="margin: 25px;" data-no-turbolink>
       <li role="presentation">
        <a href="/channels/376700/private_show" id="channel_link_private_view">Private View</a>
      </li>
      <li role="presentation" class=active>
        <a href="/channels/376700" id="channel_link_public_view">Public View</a>
      </li>
      <li role="presentation">
        <a href="/channels/376700/edit" id="channel_link_settings">Channel Settings</a>
      </li>
    
      <li role="presentation">
        <a href="apikeys.php" id="channel_link_api_keys">API Keys</a>
      </li>
      

    </ul>
  </div>