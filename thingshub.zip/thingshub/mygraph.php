<!DOCTYPE html>  
  
<html lang="en">  
<head>  
    <meta charset="utf-8">  
    <title>ThingsHub</title>  
    <meta name="viewport" content="width=device-width,initial-scale=1">  
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"> 
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/table.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>	
	
</head>  

  <body style='padding-top: 30px;'>

     <nav class="navbar navbar-inverse"  id="RedMenu">  
        <div class="container-fluid">  
            <!--Navbar Header Start Here-->  
            <div class="navbar-header">  
                <a class="navbar-brand" href="index.php"><font color="white">ThingsHub</font></a>  
				
            </div>  
            <!--Navbar Header End Here-->  
            <!--Menu Start Here-->  
            <ul class="nav navbar-nav " >  
                 <li class="dropdown">  
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">  
                        Channels  
                        <span class="caret"></span>  
                    </a>  
                    <ul class="dropdown-menu">  
                        <li><a href="mychannels.php">My channels</a></li>  
                        <li><a href="#">Watched channels</a></li>  
                        <li><a href="#">Public channels</a></li>  
                      
                    </ul>  
                </li> 
                <li><a href="#">Apps</a></li>  
				<li><a href="#">Community</a></li> 
                <!--dropdown Menu Start-->  
                <li bgcolor="#E6E6FA" class="dropdown" >  
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#"  >  
                        Support  
                        <span class="caret"></span>  
                    </a>  
                    <ul  class="dropdown-menu" >  
                        <li><a href="#">Documentation </a></li>  
                        <li><a href="#">Tutorial</a></li>  
                        <li><a href="#">Examples</a></li>  
                    </ul>  
                </li>  
                <!--dropdown Menu End-->  
                <li><a href="#">Contact Us</a></li>  
            </ul>  
            <!--Menu End Here-->  
            <!--Right Aligned Menu Start-->  
            <ul class="nav navbar-nav navbar-right">  
                 <li bgcolor="#E6E6FA" class="dropdown" >  
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#"  >  
                        Account  
                        <span class="caret"></span>  
                    </a>  
                    <ul  class="dropdown-menu" >  
                        <li><a href="login.php">My account </a></li>  
                        <li><a href="#">My profile</a></li>  
                         
                    </ul>  
                </li>  
                <li><a href="login.php">Sign out</a></li>  
            </ul>  
            <!--Right Aligned Menu End-->  
        </div>  


    </nav>  
	
	 <h1>My Channels</h1><br> <br>
	 <div class="col-pad" data-no-turbolink>

      <a class="btn btn-primary" data-no-turbolink="true" href="createChannel.php" id="channel-new-channel-btn">New Channel</a> <br>

      <br><br>


        

    </div>
	<div style="width:450px;">
	<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
</div>
	


	
	
    <!--<nav> tag end-->  
    <!--Inverted Navbar End Here-->  
    <script src="js/jquery-2.1.4.min.js"></script>  
    <script src="js/bootstrap.min.js"></script> 
<script src="code/highcharts.js"></script>
<script src="code/modules/exporting.js"></script>



		<script type="text/javascript">

$.getJSON('https://www.highcharts.com/samples/data/jsonp.php?filename=usdeur.json&callback=?', function (data) {

    Highcharts.chart('container', {
        chart: {
            zoomType: 'x'
        },
        title: {
            text: 'USD to EUR exchange rate over time'
        },
        subtitle: {
            text: document.ontouchstart === undefined ?
                    'Click and drag in the plot area to zoom in' : 'Pinch the chart to zoom in'
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'Exchange rate'
            }
        },
        legend: {
            enabled: false
        },
        plotOptions: {
            area: {
                fillColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, Highcharts.getOptions().colors[0]],
                        [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                    ]
                },
                marker: {
                    radius: 2
                },
                lineWidth: 1,
                states: {
                    hover: {
                        lineWidth: 1
                    }
                },
                threshold: null
            }
        },

        series: [{
            type: 'area',
            name: 'USD to EUR',
            data: data
        }]
    });
});
		</script>	
		
		
	<div style="width:450px;">
	<div id="container1" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
</div>


		<script type="text/javascript">

Highcharts.chart('container1', {
    chart: {
        type: 'line'
    },
    title: {
        text: 'Monthly Average Temperature'
    },
    subtitle: {
        text: 'Source: WorldClimate.com'
    },
    xAxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    },
    yAxis: {
        title: {
            text: 'Temperature (°C)'
        }
    },
    plotOptions: {
        line: {
            dataLabels: {
                enabled: true
            },
            enableMouseTracking: false
        }
    },
    series: [{
        name: 'Tokyo',
        data: [7.0, 6.9, 9.5, 14.5, 18.4, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
    }, {
        name: 'London',
        data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8]
    }]
});
		</script>	
</body>  
</html> 